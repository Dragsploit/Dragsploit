This exploit was created by Dragsploit, I am solo developer and only developer for this exploit.

DO NOT MODIFY OR REDISTRIBUTE MY EXPLOIT!


Thanks to the WeAreDevs and CheatSquad team for providing the required tools to make this exploit possible. :)

Credits to the developers of the Tools, I do not own them and they are just packaged with Dragsploit (FPS Unlocker & Lag Switch)

Credits to the people who made the IMGs in Themes

AND MOST IMPORTANTLY.  Thank you to the wonderful server staff and members of the server for being with me through the development of Dragsploit!

Offical Discord server and place to get the exploit: https://discord.gg/zqzAW5G

Official youtube reviews: 
https://www.youtube.com/watch?v=qUXpsQ7O3Pc&t=137s [OgModders - Hacking and music!]


https://youtu.be/J7dssTuiT1E [Deadmeme xx]
