﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dragsploit_Bootstrapper
{
    public partial class Form1 : Form
    {
        //Gives form round edges
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
(
   int nLeftRect,     // x-coordinate of upper-left corner
   int nTopRect,      // y-coordinate of upper-left corner
   int nRightRect,    // x-coordinate of lower-right corner
   int nBottomRect,   // y-coordinate of lower-right corner
   int nWidthEllipse, // height of ellipse
   int nHeightEllipse // width of ellipse
);

        public Form1()
        {
            InitializeComponent();

            //Gives form rounded edges
            this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));
        }

        //Make form moveaable
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Directory.Exists(@"Lib"))
            {

            }
            else
            {
                Directory.CreateDirectory(@"Lib");
            }
            if (File.Exists(@"Lib\usrdownloadeddragsploit.txt"))
            {

            }
            else
            {
                File.WriteAllText(@"Lib\usrdownloadeddragsploit.txt", "");
            }
           


            //Libraries                  

            if (File.Exists(@"Lib\oldui.txt"))
            {

            }
            else
            {
                File.WriteAllText(@"Lib\oldui.txt", "");
            }

            if (File.Exists(@"Lib\updatelog.txt"))
            {
                File.WriteAllText(@"Lib\updatelog.txt", "");
            }
            else
            {
                File.WriteAllText(@"Lib\updatelog.txt", "");
            }

            if (File.Exists(@"EasyExploits.dll"))
            {
                File.Delete(@"EasyExploits.dll");
            }
            if (File.Exists(@"EasyExploitsDLL.dll"))
            {
                File.Delete(@"EasyExploitsDLL.dll");
            }

            //Creates theme dir
            if (Directory.Exists(@"Themes\"))
            {

            }
            else
            {
                Directory.CreateDirectory(@"Themes\");
            }

            if (File.Exists(@"Themes\READ-ME.txt"))
            {

            }
            else
            {
                File.WriteAllText(@"Themes\READ-ME.txt", "To use a custom theme, copy and paste the images directory that you wish to use into the file 'dir.txt', go to the themes page in Dragsploit and click Custom.");
            }

            if (File.Exists(@"Themes\dir.txt"))
            {

            }
            else
            {
                File.WriteAllText(@"Themes\dir.txt", "");
            }

            if (File.ReadAllText(@"Lib\usrdownloadeddragsploit.txt").Equals("true"))
            {
                label2.Text = "Downloading new files...";
                label2.Visible = true;
                button1.Visible = false;
                button2.Visible = false;
            }

            //Theme save instance

            //creates theme save instance file
            if (File.Exists(@"Lib\themesave.txt"))
            {

            }
            else
            {
                File.WriteAllText(@"Lib\themesave.txt", "");
            }

            //Custom
            string custom = File.ReadAllText(@"Lib\themesave.txt");
            string dir = File.ReadAllText(@"Themes\dir.txt");
            if (custom.Equals("10"))
            {
                if (dir.Equals(""))
                {
                    this.BackgroundImage = null;
                }
                else
                {
                    Image img = Image.FromFile(dir);
                    this.BackgroundImage = img;
                }


            }

            //Space
            string space = File.ReadAllText(@"Lib\themesave.txt");
            if (space.Equals("1"))
            {
                this.BackgroundImage = global::Dragsploit_Bootstrapper.Properties.Resources.stars_background_blue_photoshop;

            }

            //Normal
            string normal = File.ReadAllText(@"Lib\themesave.txt");
            if (normal.Equals("2"))
            {
                this.BackgroundImage = null;
            }

            //Red flame
            string redflame = File.ReadAllText(@"Lib\themesave.txt");
            if (redflame.Equals("3"))
            {
                this.BackgroundImage = global::Dragsploit_Bootstrapper.Properties.Resources.Fire_awareness_fire_marshal_training1;
            }

            //Blue flame
            string blueflame = File.ReadAllText(@"Lib\themesave.txt");
            if (blueflame.Equals("4"))
            {
                this.BackgroundImage = global::Dragsploit_Bootstrapper.Properties.Resources._0;
            }

            //Abstract
            string abstract1 = File.ReadAllText(@"Lib\themesave.txt");
            if (abstract1.Equals("5"))
            {
                this.BackgroundImage = global::Dragsploit_Bootstrapper.Properties.Resources.papers_co_vj25_dark_abstract_triangle_pattern_bw_29_wallpaper;

            }

            //Red Abstract
            string abstract2 = File.ReadAllText(@"Lib\themesave.txt");
            if (abstract2.Equals("6"))
            {
                this.BackgroundImage = global::Dragsploit_Bootstrapper.Properties.Resources.black_red_abstract_polygon_3d_4k_45;

            }

            //Rain
            string rain = File.ReadAllText(@"Lib\themesave.txt");
            if (rain.Equals("7"))
            {
                this.BackgroundImage = global::Dragsploit_Bootstrapper.Properties.Resources.okna_dozhd_voda_kapli_svet;

            }

            //Forest
            string forest = File.ReadAllText(@"Lib\themesave.txt");
            if (forest.Equals("8"))
            {
                this.BackgroundImage = global::Dragsploit_Bootstrapper.Properties.Resources.wp3438344;

            }

            //Cosmos
            string cosmo = File.ReadAllText(@"Lib\themesave.txt");
            if (cosmo.Equals("9"))
            {
                this.BackgroundImage = global::Dragsploit_Bootstrapper.Properties.Resources.redspace;

            }
        }

        //downloads dragsploit if new user
        private void button1_Click(object sender, EventArgs e)
        {
            focus.Focus();
            label2.Visible = true;
            button1.Visible = false;


            File.WriteAllText(@"Lib\usrdownloadeddragsploit.txt", "true");

            // Config
            String pname = "Dragsploit.exe";
            string pname2 = "WeAreDevs_API.dll";
            string pname3 = "scripts!.zip";
            string pname4 = "credits-README.txt";
            string pname5 = "FastColoredTextBox.dll";
            string pname8 = "CheatSquadAPI.dll";
            string pname9 = "Tools.zip";
            String dlink = "https://pastebin.com/raw/8mmAJQVM";
            string dlink2 = "https://pastebin.com/raw/bqS4ssty";
            string dlink3 = "https://pastebin.com/raw/Ze3m3nw9";
            string dlink4 = "https://pastebin.com/raw/yDtZKM8n";
            string dlink5 = "https://pastebin.com/raw/raPDAP2Q";
            string dlink8 = "https://pastebin.com/raw/eDb9iRaT";
            string dlink9 = "https://pastebin.com/raw/CdxHiEaY";
            string title = @"Dragsploit Bootstrapper.
";
          
            WebClient wc = new WebClient();
            String key = wc.DownloadString(dlink);
            string key2 = wc.DownloadString(dlink2);
            string key3 = wc.DownloadString(dlink3);
            string key4 = wc.DownloadString(dlink4);
            string key5 = wc.DownloadString(dlink5);
            string key8 = wc.DownloadString(dlink8);
            string key9 = wc.DownloadString(dlink9);
            String path = @"" + pname + "";
            string path2 = @"" + pname2 + "";
            string path3 = @"" + pname3 + "";
            string path4 = @"" + pname4 + "";
            string path5 = @"" + pname5 + "";
            string path8 = @"" + pname8 + "";
            string path9 = @"" + pname9 + "";
            System.Net.WebClient Dow = new WebClient();
            String patch = (@"Dragsploit");
            Dow.DownloadFile(key, path);
            Dow.DownloadFile(key2, path2);
            Dow.DownloadFile(key3, path3);
            Dow.DownloadFile(key4, path4);
            Dow.DownloadFile(key5, path5);
            Dow.DownloadFile(key8, path8);
            Dow.DownloadFile(key9, path9);
            string zipPath = @"scripts!.zip";
            string extract = "Scripts";
            if (Directory.Exists(@"Scripts"))
            {
                Directory.Delete(@"Scripts", true);
            }
            ZipFile.ExtractToDirectory(zipPath, extract);
            if (File.Exists(@"scripts!.zip"))
            {
                File.Delete(@"scripts!.zip");
            }
            string zipPath2 = @"Tools.zip";
            string extract2 = "Tools";
            if (Directory.Exists(@"Tools"))
            {
                Directory.Delete(@"Tools", true);
            }
            ZipFile.ExtractToDirectory(zipPath2, extract2);
            if (File.Exists(@"Tools.zip"))
            {
                File.Delete(@"Tools.zip");
            }
            if (File.Exists(@"Tools\Tools\VPN\README.txt"))
            {
                File.Delete(@"Tools\Tools\VPN\README.txt");
            }
            File.WriteAllText(@"Tools\Tools\VPN\README.txt", "To change the VPN server, open 'VpnConnection.pbk', click 'Properties', then go to 'https://www.vpngate.net/en/' and copy the hostname (NOT IP) of a server that has L2TP/IPsec and then delete the current hostname apply the new copied hostname to the txt box, click 'OK' and exit and your done!");
            label2.Text = "Finished!";
            button3.Visible = true;
            button2.Visible = true;
     
            






        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer4.Stop();
            timer1.Stop();
           
            File.WriteAllText(@"Lib\usrdownloadeddragsploit.txt", "true");

            // Config
            String pname = "Dragsploit.exe";
            string pname2 = "WeAreDevs_API.dll";
            string pname3 = "scripts!.zip";
            string pname4 = "credits-README.txt";
            string pname5 = "FastColoredTextBox.dll";
            string pname8 = "CheatSquadAPI.dll";
            string pname9 = "Tools.zip";
            String dlink = "https://pastebin.com/raw/8mmAJQVM";
            string dlink2 = "https://pastebin.com/raw/bqS4ssty";
            string dlink3 = "https://pastebin.com/raw/Ze3m3nw9";
            string dlink4 = "https://pastebin.com/raw/yDtZKM8n";
            string dlink5 = "https://pastebin.com/raw/raPDAP2Q";
            string dlink8 = "https://pastebin.com/raw/eDb9iRaT";
            string dlink9 = "https://pastebin.com/raw/CdxHiEaY";
            string title = @"Dragsploit Bootstrapper.
";

            WebClient wc = new WebClient();
            String key = wc.DownloadString(dlink);
            string key2 = wc.DownloadString(dlink2);
            string key3 = wc.DownloadString(dlink3);
            string key4 = wc.DownloadString(dlink4);
            string key5 = wc.DownloadString(dlink5);
            string key8 = wc.DownloadString(dlink8);
            string key9 = wc.DownloadString(dlink9);
            String path = @"" + pname + "";
            string path2 = @"" + pname2 + "";
            string path3 = @"" + pname3 + "";
            string path4 = @"" + pname4 + "";
            string path5 = @"" + pname5 + "";
            string path8 = @"" + pname8 + "";
            string path9 = @"" + pname9 + "";
            System.Net.WebClient Dow = new WebClient();
            String patch = (@"Dragsploit");
            Dow.DownloadFile(key, path);
            Dow.DownloadFile(key2, path2);
            Dow.DownloadFile(key3, path3);
            Dow.DownloadFile(key4, path4);
            Dow.DownloadFile(key5, path5);
            Dow.DownloadFile(key8, path8);
            Dow.DownloadFile(key9, path9);
            string zipPath = @"scripts!.zip";
            string extract = "Scripts";
            if (Directory.Exists(@"Scripts"))
            {
                Directory.Delete(@"Scripts", true);
            }
            ZipFile.ExtractToDirectory(zipPath, extract);
            if (File.Exists(@"scripts!.zip"))
            {
                File.Delete(@"scripts!.zip");
            }
            string zipPath2 = @"Tools.zip";
            string extract2 = "Tools";
            if (Directory.Exists(@"Tools"))
            {
                Directory.Delete(@"Tools", true);
            }
            ZipFile.ExtractToDirectory(zipPath2, extract2);
            if (File.Exists(@"Tools.zip"))
            {
                File.Delete(@"Tools.zip");
            }
            if (File.Exists(@"Tools\Tools\VPN\README.txt"))
            {
                File.Delete(@"Tools\Tools\VPN\README.txt");
            }
            File.WriteAllText(@"Tools\Tools\VPN\README.txt", "To change the VPN server, open 'VpnConnection.pbk', click 'Properties', then go to 'https://www.vpngate.net/en/' and copy the hostname (NOT IP) of a server that has L2TP/IPsec and then delete the current hostname apply the new copied hostname to the txt box, click 'OK' and exit and your done!");
            label2.Text = "Finished!";
            timer3.Start();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer2.Start();
            focus.Focus();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (Opacity > 0.0D)
            {
                Opacity -= 0.10D;
            }
            if (Opacity == 0.0D)
            {
                timer2.Stop();
                Process.Start(@"Dragsploit.exe");
                Application.Exit();
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Stop();
            timer2.Start();
        }

        //focus remove
        private void label2_Click(object sender, EventArgs e)
        {
            focus.Focus();
        }

        private void Form1_MouseLeave(object sender, EventArgs e)
        {
            focus.Focus();
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            CenterToScreen();
            DoubleBuffered = true;
            //Gives form round edges
            this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));
            if (Width < 515)
            {
                CenterToScreen();
                Width += 25;
                if (Width > 515)
                {
                    Width = 515;
                }
            }
            if (Width == 515)
            {
                if (Height < 177)
                {
                    CenterToScreen();
                    Height += 9;
                    if (Height > 177)
                    {
                        Height = 175;
                        if (File.ReadAllText(@"Lib\usrdownloadeddragsploit.txt").Equals("true"))
                        {
                            label2.Text = "Downloading new files...";
                            label2.Visible = true;
                            button1.Visible = false;
                            button2.Visible = false;
                            timer1.Start();
                        }
                        Enabled = true;
                        timer4.Enabled = false;
                    }
                }
            }
        }
    }
}
